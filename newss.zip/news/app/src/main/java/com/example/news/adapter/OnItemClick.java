package com.example.news.adapter;

public interface OnItemClick {

    void onClickListListener(int i);

    void onClickGridListener(int i);

}
