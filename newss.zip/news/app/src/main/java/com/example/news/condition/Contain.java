package com.example.news.condition;

public class Contain {
    public static final short NUMBER_ZERO = 0;

    public static final short NUMBER_ONE = 1;

    public static final short NUMBER_TWO = 2;

    public static final short NUMBER_THREE = 3;

    public static final short NUMBER_FOUR = 4;

    public static final short NUMBER_FIVE = 5;

    public static final short NUMBER_SIX = 6;

    public static final short REQUEST_CODE_PERMISSION[] = new short[]{1, 2, 3};

    public static final short TIME_DELAY_BACK_FRAGMENT = 100;

    public static final short TIME_DELAY_SCROLL_RECYCLE = 100;

    public static final short HEIGHT_VIDEO = 800;

    public static final String KEY_API = "AIzaSyBGmYnqXV1cg-EzGESV5eFkP3Ye7AhRWbo";

    public static final short GRID_COLUMN = 3;

    public static final short RESULTS_MAX = 50;

    public static final String CHANNEL_ID = "UCVRqZH5QnrnbMWhElPBD-MQ";

    public static final String PART_PLAYLIST = "snippet";

    public static final String DATABASE_NAME = "db_news.sqlite";

    public static final String EMAIL_ADMIN = "khaiphan16121997@gmail.com.vn";
}
