package com.example.news.view.fragment;

import android.support.v4.app.Fragment;

public interface OnChangeFragment {
    /**
     *
     */
    void setOnChangeFragment(final Fragment fragment);
}
