package com.example.news.view.fragment;

public interface YouTubePlayVideo {
    void setYouTubePlayVideo(final String id);
}
