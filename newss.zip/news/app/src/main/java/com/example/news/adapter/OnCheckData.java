package com.example.news.adapter;

import com.example.news.model.Video;

import java.util.List;

public interface OnCheckData {
    void setOnCheckData(List<Video> list);
}
