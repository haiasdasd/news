package com.example.news.view.fragment;

public interface RefreshListData {
    void setOnRefreshListData(final boolean flag);
}
